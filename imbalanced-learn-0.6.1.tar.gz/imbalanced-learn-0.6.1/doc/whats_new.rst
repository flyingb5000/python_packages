.. currentmodule:: imblearn

===============
Release history
===============

.. include:: whats_new/v0.6.rst

.. include:: whats_new/v0.5.rst

.. include:: whats_new/v0.4.rst

.. include:: whats_new/v0.3.rst

.. include:: whats_new/v0.2.rst

.. include:: whats_new/v0.1.rst
